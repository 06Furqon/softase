<?php 

	$conn = mysqli_connect("localhost","root","","covid");
	//									username,pass,namadatabase

?>