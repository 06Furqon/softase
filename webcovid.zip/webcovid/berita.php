<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="img/virus1.png">
        <title>Berita | Covid19</title> 
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, inital-scale=1">
        <link rel="stylesheet" href="css/coba.css"> 
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    </head>
    <body>
<nav class="container berita">
        <h1>Berita</h1>
        <div class="row">
          <div class="col jumbotron berita-covid">
            <img src="img/pakaimasker.jpg" class="image-1" alt="">
            <h3>Menggunakan Masker</h3>
            <p class="card-text">Menurut pedoman, mengenakan masker wajah sangat penting saat berada di dalam ruangan, karena penularan super lebih mungkin terjadi di dalam ruangan. Oleh karena itu, wajib bagi semua orang berusia 2 tahun ke atas memakai masker saat berada di dalam ruangan dan di sekitar orang yang tidak tinggal serumah</p>
          </div>
          <div class="col jumbotron berita-covid">
            <img src="img/pakaimasker.jpg" class="image-1" alt="">
            <h3>Menggunakan Masker</h3>
            <p class="card-text">Menurut pedoman, mengenakan masker wajah sangat penting saat berada di dalam ruangan, karena penularan super lebih mungkin terjadi di dalam ruangan. Oleh karena itu, wajib bagi semua orang berusia 2 tahun ke atas memakai masker saat berada di dalam ruangan dan di sekitar orang yang tidak tinggal serumah</p>
          </div>
        </div>

        <div class="row">
          <div class="col jumbotron berita-covid">
            <img src="img/tangan.jpg" class="image-1" alt="">
            <h3>Mencuci Tangan</h3>
            <p class="card-text">Mencuci tangan dengan sabun dapat menghilangkan kuman dari tangan dan mencegah terjadinya infeksi karena tanpa sadar kita sering menyentuh mata, hidung, mulut maupun bagian tubuh lainnya. selain itu kuman dari tangan dapat menyebar ke permukaan meja, mainan lalu berpindah ke tangan orang lain.</p>
          </div>
          <div class="col jumbotron berita-covid">
            <img src="img/pakaimasker.jpg" class="image-1" alt="">
            <h3>Menggunakan Masker</h3>
            <p class="card-text">Menurut pedoman, mengenakan masker wajah sangat penting saat berada di dalam ruangan, karena penularan super lebih mungkin terjadi di dalam ruangan. Oleh karena itu, wajib bagi semua orang berusia 2 tahun ke atas memakai masker saat berada di dalam ruangan dan di sekitar orang yang tidak tinggal serumah</p>
          </div>
        </div>  

        <div class="row">
          <div class="col">
            <img src="img/dumbbell.png" class="image" alt="">
          </div>
          <div class="col jumbotron berita-covid">
            <img src="img/olahraga.jpg" class="image-1" alt="">
            <h3>Berolahraga</h3>
            <p class="card-text">Berolahraga di luar ruangan bisa menjadi salah satu alternatif, selama tidak berkerumun. Apalagi menurut para ahli virus korona tidak tahan dengan sinar matahari. Selain itu, berolahraga outdoor juga bisa menghilangkan suntuk dan dapat memberikan asupan vitamin D dari sinar matahari</p>
          </div>
        </div>
    </nav>
  </body>
  </html>